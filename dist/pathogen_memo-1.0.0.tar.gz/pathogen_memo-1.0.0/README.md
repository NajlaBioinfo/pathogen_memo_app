# PathogenMemoApp
A Flask REST-API displaying some characteristics of serveral Pathogens/Potential Pathogens (demo).

#### DOCKER IMAGE
 ```bash
docker pull najlabioinfo/docker-pathogen-memo
```


#### URL
* <a href="https://pathogen-memo.herokuapp.com">https://pathogen-memo.herokuapp.com</a>

#### Author
NajlaBioinfo

#### LICENSE
MIT
